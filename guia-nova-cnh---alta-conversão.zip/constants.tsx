
import React from 'react';
import { CheckCircle, ShieldCheck, Zap, Brain, ClipboardCheck, Timer } from 'lucide-react';

export const TESTIMONIALS = [
  {
    id: 1,
    name: "Lucas Silva",
    role: "Aprovado de Primeira",
    content: "Eu estava morrendo de medo da baliza. O guia me deu um passo a passo tão simples que parecia que o instrutor estava do meu lado. Passei sem erros!",
    avatar: "https://picsum.photos/id/64/100/100"
  },
  {
    id: 2,
    name: "Mariana Costa",
    role: "Recuperou a confiança",
    content: "Já tinha reprovado 2 vezes por puro nervosismo. As técnicas de controle emocional do guia mudaram tudo. Recomendo muito!",
    avatar: "https://picsum.photos/id/65/100/100"
  },
  {
    id: 3,
    name: "Roberto Júnior",
    role: "Estudante",
    content: "O conteúdo teórico é muito direto. Não fica enrolando com leis chatas, foca exatamente no que cai na prova. Valeu cada centavo.",
    avatar: "https://picsum.photos/id/66/100/100"
  }
];

export const BONUSES = [
  {
    title: "Checklist Final",
    description: "Tudo o que você precisa conferir 10 minutos antes da prova.",
    icon: "📋"
  },
  {
    title: "Roteiro da Baliza",
    description: "O mapa mental para nunca mais esquecer a sequência de movimentos.",
    icon: "🚗"
  },
  {
    title: "Técnica Anti-Ansiedade",
    description: "Exercício respiratório para manter a calma total diante do examinador.",
    icon: "🧘"
  },
  {
    title: "Plano de Estudo Express",
    description: "Aprenda o que importa em apenas 7 dias.",
    icon: "📅"
  }
];

export const FAQS = [
  {
    question: "O guia serve para qualquer estado?",
    answer: "Sim! O conteúdo é baseado nas normas nacionais de trânsito atualizadas para 2026."
  },
  {
    question: "Como recebo o acesso?",
    answer: "Imediatamente após a confirmação do pagamento, você recebe le link de download no seu e-mail."
  },
  {
    question: "Já reprovei antes, o guia ajuda?",
    answer: "Com certeza. Temos um módulo focado justamente em quem já reprovou e precisa vencer o trauma e os vícios."
  }
];
