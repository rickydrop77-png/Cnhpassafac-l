
import React, { useState, useEffect } from 'react';
import { 
  CheckCircle, 
  ShieldCheck, 
  ArrowRight,
  Car,
  Lock,
  Flame,
  Brain,
  Key,
  Sparkles,
  Users,
  Award,
  Star,
  ChevronDown,
  ChevronUp,
  MessageCircle,
  Gift,
  Eye,
  ShieldAlert,
  Navigation,
  Check,
  ThumbsUp,
  PlayCircle,
  Headphones
} from 'lucide-react';
import { TESTIMONIALS, BONUSES, FAQS } from './constants.tsx';

const App: React.FC = () => {
  const [timeLeft, setTimeLeft] = useState({ min: 14, sec: 59 });
  const [showNotification, setShowNotification] = useState(false);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);
  const [vagas, setVagas] = useState(12);
  const [planType, setPlanType] = useState<'ebook' | 'club'>('ebook');
  const [isRedirecting, setIsRedirecting] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.sec > 0) return { ...prev, sec: prev.sec - 1 };
        if (prev.min > 0) return { min: prev.min - 1, sec: 59 };
        return prev;
      });
    }, 1000);

    const notify = setTimeout(() => setShowNotification(true), 3000);
    const hideNotify = setTimeout(() => setShowNotification(false), 8000);

    const vagasTimer = setInterval(() => {
      setVagas(prev => (prev > 3 ? prev - 1 : prev));
    }, 30000);

    return () => {
      clearInterval(timer);
      clearInterval(vagasTimer);
      clearTimeout(notify);
      clearTimeout(hideNotify);
    };
  }, []);

  const scrollToOffer = () => {
    const element = document.getElementById('offer');
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleCheckout = () => {
    setIsRedirecting(true);
    
    // Link oficial fornecido pelo usuário
    const checkoutUrl = "https://pay.cakto.com.br/adfe6vx_724824";
    
    // Pequeno delay para feedback visual de "Segurança" antes de sair da página
    setTimeout(() => {
      window.location.href = checkoutUrl;
    }, 800);
  };

  return (
    <div className="min-h-screen flex flex-col items-center overflow-x-hidden selection:bg-[#5A6ED8] selection:text-white pb-36">
      
      {/* Overlay de Redirecionamento */}
      {isRedirecting && (
        <div className="fixed inset-0 z-[1000] bg-[#000018] flex flex-col items-center justify-center animate-fadeIn">
            <div className="w-12 h-12 border-4 border-[#5A6ED8] border-t-transparent rounded-full animate-spin mb-4"></div>
            <p className="text-white font-bold text-sm tracking-widest uppercase animate-pulse">Criptografando Conexão...</p>
        </div>
      )}

      {/* Alerta de Urgência Topo - Estilo Sticky */}
      <div className="w-full bg-gradient-to-r from-[#5A6ED8] to-[#243799] py-2.5 text-center text-[10px] font-[800] text-white uppercase tracking-[0.15em] shadow-lg z-[110]">
        ⚠️ Atenção: Desconto expira em <span className="bg-white/20 px-1.5 py-0.5 rounded mx-1 font-mono">{timeLeft.min}:{timeLeft.sec.toString().padStart(2, '0')}</span>
      </div>

      {/* Header Compacto */}
      <nav className="w-full max-w-md px-6 py-4 flex justify-between items-center z-[100] absolute top-10">
        <div className="flex items-center gap-2 glass-card px-3 py-1.5 rounded-full">
          <div className="bg-[#5A6ED8] p-1 rounded-full shadow-lg">
            <Car size={14} className="text-white" />
          </div>
          <span className="font-extrabold tracking-tighter text-xs uppercase text-white">Guia<span className="text-[#5A6ED8]">CNH</span></span>
        </div>
        <div className="glass-card bg-emerald-500/10 text-emerald-400 text-[9px] font-black px-3 py-1.5 rounded-full border border-emerald-500/20 flex items-center gap-1.5 animate-pulse">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          {1242 + (12 - vagas)} ONLINE
        </div>
      </nav>

      {/* Hero Section Premium */}
      <header className="w-full max-w-md px-6 pt-24 pb-12 text-center relative overflow-hidden">
        {/* Background Effects */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[500px] h-[500px] bg-[#5A6ED8]/20 blur-[100px] -z-10 rounded-full mix-blend-screen"></div>
        
        <div className="inline-flex items-center gap-2 px-4 py-1.5 mb-6 rounded-full bg-[#5A6ED8]/10 border border-[#5A6ED8]/30 text-[#5A6ED8] text-[9px] font-black uppercase tracking-[0.2em] shadow-[0_0_20px_rgba(90,110,216,0.2)]">
          <Sparkles size={10} fill="currentColor" /> Método 2026 Validado
        </div>

        <h1 className="text-[40px] font-[1000] leading-[0.95] mb-6 tracking-tight text-white drop-shadow-xl">
          Sua CNH na Mão <br/>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#5A6ED8] via-white to-[#5A6ED8] animate-pulse">Sem Nervosismo</span>
        </h1>

        <p className="text-[#CFD0D8] text-base mb-8 leading-relaxed font-medium px-2">
          O passo a passo prático para <span className="text-white font-bold bg-[#5A6ED8]/20 px-1 rounded">eliminar a ansiedade</span> e passar de primeira, mesmo que você nunca tenha dirigido.
        </p>

        {/* Hero Visual - Badge 3D */}
        <div className="relative mb-10 inline-block transform hover:scale-105 transition-transform duration-500">
            <div className="absolute -inset-4 bg-gradient-to-b from-[#5A6ED8] to-transparent opacity-20 blur-xl rounded-full"></div>
            <div className="glass-card p-6 rounded-[32px] border-white/10 flex items-center justify-center relative bg-gradient-to-br from-[#ffffff]/5 to-[#000000]/20">
                <div className="bg-gradient-to-br from-[#5A6ED8] to-[#243799] p-4 rounded-2xl shadow-inner">
                    <Award size={48} className="text-white" strokeWidth={1.5} />
                </div>
                <div className="absolute -bottom-3 bg-emerald-500 text-white text-[9px] font-black px-3 py-1 rounded-full shadow-lg border border-[#000018] flex items-center gap-1">
                    <CheckCircle size={10} fill="white" className="text-emerald-600"/> APROVAÇÃO
                </div>
            </div>
        </div>

        <button 
          onClick={scrollToOffer}
          className="btn-shine w-full py-5 px-6 bg-[#5A6ED8] hover:bg-[#4a5ec7] transition-all rounded-[24px] text-lg font-[900] text-white shadow-[0_10px_40px_-10px_rgba(90,110,216,0.6)] flex items-center justify-center gap-2 group active:scale-[0.98]"
        >
          QUERO PASSAR DE PRIMEIRA <ArrowRight size={20} strokeWidth={3} className="group-hover:translate-x-1 transition-transform" />
        </button>
        
        <div className="mt-4 flex items-center justify-center gap-2 text-[10px] text-zinc-500 font-bold uppercase tracking-wide">
            <ShieldCheck size={12} className="text-emerald-500"/> Compra Segura • Acesso Imediato
        </div>
      </header>

      {/* Timeline Section */}
      <section className="w-full max-w-md px-6 py-12 relative">
        <div className="absolute left-0 top-0 w-full h-full bg-gradient-to-b from-transparent via-[#5A6ED8]/5 to-transparent pointer-events-none"></div>
        
        <div className="text-center mb-12">
          <h2 className="text-[10px] font-black text-[#5A6ED8] uppercase tracking-[0.3em] mb-2 border-b border-[#5A6ED8]/30 inline-block pb-1">Por dentro do Guia</h2>
          <h3 className="text-2xl font-[1000] text-white leading-tight">O Mapa da <span className="text-[#5A6ED8]">Sua Aprovação</span></h3>
        </div>

        <div className="space-y-0 relative">
          <div className="absolute left-[23px] top-4 bottom-4 w-[2px] bg-[#5A6ED8]/20 rounded-full"></div>

          <div className="relative flex gap-5 group pb-10">
            <div className="z-10 flex-shrink-0 w-12 h-12 rounded-full bg-[#000018] border-2 border-[#5A6ED8] flex items-center justify-center shadow-[0_0_20px_rgba(90,110,216,0.3)] group-hover:scale-110 transition-transform duration-300">
              <Brain size={20} className="text-white" />
            </div>
            <div className="pt-1">
              <h4 className="text-white font-[900] text-sm uppercase tracking-tight mb-1 flex items-center gap-2">
                01. Blindagem Mental <span className="text-[8px] bg-[#5A6ED8] text-white px-1.5 py-0.5 rounded">VITAL</span>
              </h4>
              <p className="text-[#CFD0D8] text-xs leading-relaxed font-medium">
                A técnica de respiração militar para eliminar o tremor nas pernas e o "branco" na hora H.
              </p>
            </div>
          </div>

          <div className="relative flex gap-5 group pb-10">
            <div className="z-10 flex-shrink-0 w-12 h-12 rounded-full bg-[#000018] border-2 border-emerald-500 flex items-center justify-center shadow-[0_0_20px_rgba(16,185,129,0.3)] group-hover:scale-110 transition-transform duration-300">
              <Navigation size={20} className="text-white" />
            </div>
            <div className="pt-1">
              <h4 className="text-white font-[900] text-sm uppercase tracking-tight mb-1">02. Baliza Perfeita</h4>
              <p className="text-[#CFD0D8] text-xs leading-relaxed font-medium">
                Esqueça decorar passos. Aprenda os 3 pontos visuais universais que funcionam em qualquer carro.
              </p>
            </div>
          </div>

          <div className="relative flex gap-5 group pb-10">
            <div className="z-10 flex-shrink-0 w-12 h-12 rounded-full bg-[#000018] border-2 border-amber-500 flex items-center justify-center shadow-[0_0_20px_rgba(245,158,11,0.3)] group-hover:scale-110 transition-transform duration-300">
              <ShieldAlert size={20} className="text-white" />
            </div>
            <div className="pt-1">
              <h4 className="text-white font-[900] text-sm uppercase tracking-tight mb-1">03. Anti-Pegadinhas</h4>
              <p className="text-[#CFD0D8] text-xs leading-relaxed font-medium">
                Mapeamos as frases que os examinadores usam para te induzir ao erro (e como responder).
              </p>
            </div>
          </div>

          <div className="relative flex gap-5 group">
            <div className="z-10 flex-shrink-0 w-12 h-12 rounded-full bg-[#000018] border-2 border-blue-400 flex items-center justify-center shadow-[0_0_20px_rgba(96,165,250,0.3)] group-hover:scale-110 transition-transform duration-300">
              <Eye size={20} className="text-white" />
            </div>
            <div className="pt-1">
              <h4 className="text-white font-[900] text-sm uppercase tracking-tight mb-1">04. Visão de Águia</h4>
              <p className="text-[#CFD0D8] text-xs leading-relaxed font-medium">
                Entenda exatamente o que o examinador anota na prancheta e jogue com o regulamento a seu favor.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Social Proof */}
      <section className="w-full py-12 bg-white/[0.02] border-y border-white/5">
        <div className="max-w-md mx-auto px-6">
          <div className="flex items-center justify-between mb-8">
             <h2 className="text-sm font-black uppercase tracking-[0.2em] text-white">Resultados Reais</h2>
             <div className="flex gap-1">
                 {[...Array(5)].map((_, i) => <Star key={i} size={12} fill="#FFD700" className="text-[#FFD700]" />)}
             </div>
          </div>

          <div className="flex gap-4 overflow-x-auto pb-4 snap-x hide-scrollbar">
            {TESTIMONIALS.map((t) => (
              <div key={t.id} className="min-w-[280px] snap-center glass-card p-5 rounded-[24px] border-white/5 relative flex flex-col justify-between">
                <div>
                  <div className="flex gap-3 items-center mb-3">
                    <img src={t.avatar} alt={t.name} className="w-10 h-10 rounded-full border border-white/20" />
                    <div>
                      <h4 className="text-white font-bold text-sm leading-none">{t.name}</h4>
                      <p className="text-[#5A6ED8] text-[9px] font-black uppercase mt-1">{t.role}</p>
                    </div>
                  </div>
                  <p className="text-zinc-300 text-xs leading-relaxed">"{t.content}"</p>
                </div>
                <div className="mt-4 flex items-center gap-1.5 text-[9px] text-emerald-400 font-bold uppercase opacity-80">
                  <CheckCircle size={10} /> Compra Verificada
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Bonuses Grid */}
      <section className="w-full max-w-md px-6 py-12">
         <div className="glass-card rounded-[40px] p-6 border-emerald-500/20 bg-emerald-900/5 relative overflow-hidden">
            <div className="absolute -right-10 -top-10 w-32 h-32 bg-emerald-500/20 blur-[50px] rounded-full"></div>
            
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-emerald-500 text-[#000018] p-2 rounded-xl rotate-3">
                <Gift size={24} strokeWidth={2.5} />
              </div>
              <div>
                <p className="text-emerald-500 text-[10px] font-black uppercase tracking-wider">Bônus Exclusivos</p>
                <h3 className="text-white font-[1000] text-xl leading-none">Leve Tudo Grátis</h3>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {BONUSES.map((bonus, idx) => (
                <div key={idx} className="bg-[#000018]/60 p-3 rounded-2xl border border-white/5 hover:border-emerald-500/30 transition-colors">
                  <div className="text-xl mb-2">{bonus.icon}</div>
                  <h3 className="text-[10px] font-black text-white uppercase mb-1 leading-tight">{bonus.title}</h3>
                  <p className="text-zinc-400 text-[8px] leading-tight">{bonus.description}</p>
                </div>
              ))}
            </div>
         </div>
      </section>

      {/* Offer Section */}
      <section id="offer" className="w-full max-w-md px-4 py-8">
        <div className="relative">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-[#5A6ED8]/30 blur-[60px] rounded-full animate-pulse"></div>

          <div className="glass-card rounded-[48px] border-[#5A6ED8]/50 shadow-[0_0_50px_-10px_rgba(90,110,216,0.4)] relative overflow-hidden transition-all duration-500">
            {/* Plan Switcher */}
            <div className="bg-[#000018] p-1.5 mx-6 mt-6 rounded-full border border-white/10 flex relative z-20">
              <button 
                onClick={() => setPlanType('ebook')}
                className={`flex-1 py-3 rounded-full text-[10px] font-[900] uppercase tracking-wide transition-all duration-300 ${planType === 'ebook' ? 'bg-[#5A6ED8] text-white shadow-lg' : 'text-zinc-500 hover:text-white'}`}
              >
                Guia Digital
              </button>
              <button 
                onClick={() => setPlanType('club')}
                className={`flex-1 py-3 rounded-full text-[10px] font-[900] uppercase tracking-wide transition-all duration-300 flex items-center justify-center gap-1 ${planType === 'club' ? 'bg-[#5A6ED8] text-white shadow-lg' : 'text-zinc-500 hover:text-white'}`}
              >
                <Sparkles size={10} /> Clube VIP
              </button>
            </div>

            <div className="p-8 text-center">
              
              <div className="space-y-3 mb-8 min-h-[140px]">
                <div className="flex items-center gap-3 text-left">
                  <div className="bg-emerald-500/20 p-1 rounded-full"><Check size={14} className="text-emerald-400" strokeWidth={3} /></div>
                  <span className="text-zinc-300 text-xs font-bold">Guia Completo Nova CNH</span>
                </div>
                <div className="flex items-center gap-3 text-left">
                  <div className="bg-emerald-500/20 p-1 rounded-full"><Check size={14} className="text-emerald-400" strokeWidth={3} /></div>
                  <span className="text-zinc-300 text-xs font-bold">4 Bônus Premium</span>
                </div>
                
                {planType === 'ebook' ? (
                  <>
                    <div className="flex items-center gap-3 text-left">
                      <div className="bg-emerald-500/20 p-1 rounded-full"><Check size={14} className="text-emerald-400" strokeWidth={3} /></div>
                      <span className="text-zinc-300 text-xs font-bold">Atualizações 2026</span>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="flex items-center gap-3 text-left animate-fadeIn">
                      <div className="bg-[#5A6ED8] p-1 rounded-full"><PlayCircle size={14} className="text-white" strokeWidth={3} /></div>
                      <span className="text-white text-xs font-bold">Vídeos de Percurso Comentados</span>
                    </div>
                    <div className="flex items-center gap-3 text-left animate-fadeIn">
                      <div className="bg-[#5A6ED8] p-1 rounded-full"><MessageCircle size={14} className="text-white" strokeWidth={3} /></div>
                      <span className="text-white text-xs font-bold">Grupo VIP no WhatsApp</span>
                    </div>
                    <div className="flex items-center gap-3 text-left animate-fadeIn">
                      <div className="bg-[#5A6ED8] p-1 rounded-full"><Headphones size={14} className="text-white" strokeWidth={3} /></div>
                      <span className="text-white text-xs font-bold">Plantão Tira-Dúvidas 24h</span>
                    </div>
                  </>
                )}
              </div>

              <div className="relative py-6 border-t border-dashed border-white/10 transition-all duration-300">
                 <div className="absolute -left-12 -top-3 w-6 h-6 bg-[#000018] rounded-full"></div>
                 <div className="absolute -right-12 -top-3 w-6 h-6 bg-[#000018] rounded-full"></div>
                 
                 <p className="text-zinc-500 text-xs font-bold line-through mb-1">
                   {planType === 'ebook' ? 'De R$ 120,00 por' : 'De R$ 49,90 por'}
                 </p>
                 <div className="flex items-start justify-center text-white">
                    <span className="text-2xl font-bold mt-2 opacity-80">R$</span>
                    <span className="text-[80px] font-[1000] leading-none tracking-tighter text-transparent bg-clip-text bg-gradient-to-b from-white to-zinc-400 transition-all duration-300">
                      {planType === 'ebook' ? '29' : '19'}
                    </span>
                    <div className="flex flex-col text-left mt-2">
                        <span className="text-3xl font-[1000] leading-none text-zinc-300">,90</span>
                        <span className="text-[9px] text-emerald-400 font-black uppercase tracking-wider">
                          {planType === 'ebook' ? 'À Vista' : '/ Mês'}
                        </span>
                    </div>
                 </div>
              </div>

              <button 
                onClick={handleCheckout}
                disabled={isRedirecting}
                className={`btn-shine w-full py-6 transition-all rounded-[20px] text-xl font-[1000] text-white shadow-[0_10px_30px_-5px_rgba(90,110,216,0.5)] active:scale-[0.98] border border-white/20 disabled:opacity-50 ${planType === 'ebook' ? 'bg-[#5A6ED8] hover:bg-[#4a5ec7]' : 'bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400'}`}
              >
                {isRedirecting ? 'PROCESSANDO...' : (planType === 'ebook' ? 'COMPRAR GUIA' : 'ASSINAR CLUBE VIP')}
              </button>

              <div className="mt-6 flex flex-col gap-2">
                 <div className="flex justify-center gap-4 opacity-50 grayscale hover:grayscale-0 transition-all">
                    <img src="https://img.icons8.com/color/48/visa.png" className="h-5" alt="Visa" />
                    <img src="https://img.icons8.com/color/48/mastercard.png" className="h-5" alt="Mastercard" />
                    <img src="https://img.icons8.com/color/48/pix.png" className="h-5" alt="Pix" />
                 </div>
                 <p className="text-[9px] text-zinc-500 font-bold uppercase tracking-wide">Ambiente Criptografado 256-bit</p>
              </div>

            </div>
          </div>
        </div>
      </section>

      {/* Premium Guarantee Seal Section */}
      <section className="w-full max-w-md px-6 py-6 mb-8">
        <div className="relative p-6 rounded-[32px] bg-gradient-to-br from-emerald-900/20 to-emerald-900/5 border border-emerald-500/20 text-center overflow-hidden group">
            <div className="absolute top-0 right-0 w-20 h-20 bg-emerald-500/20 blur-[30px] rounded-full"></div>
            
            <div className="relative z-10 flex flex-col items-center">
                <div className="w-16 h-16 bg-gradient-to-br from-emerald-400 to-emerald-600 rounded-full flex items-center justify-center shadow-lg mb-4 border-4 border-[#000018] group-hover:scale-110 transition-transform duration-300">
                    <ThumbsUp size={28} className="text-[#000018] fill-current" />
                </div>
                
                <h3 className="text-white font-[1000] uppercase text-sm tracking-widest mb-2">Risco Zero</h3>
                <p className="text-[#CFD0D8] text-xs leading-relaxed max-w-[260px]">
                    Você tem <strong className="text-emerald-400">7 dias</strong> para testar. Se não sentir que sua aprovação está garantida, devolvemos 100% do seu dinheiro.
                </p>
                <div className="mt-4 px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full text-[9px] font-black text-emerald-400 uppercase tracking-wide flex items-center gap-1.5">
                    <ShieldCheck size={12} /> Garantia Blindada
                </div>
            </div>
        </div>
      </section>

      {/* FAQ Accordion */}
      <section className="w-full max-w-md px-6 py-12">
        <h2 className="text-lg font-[900] text-white text-center mb-8 uppercase tracking-widest border-b border-white/5 pb-4">Dúvidas?</h2>
        <div className="space-y-3">
          {FAQS.map((faq, idx) => (
            <div key={idx} className={`glass-card rounded-2xl border-white/5 overflow-hidden transition-all duration-300 ${activeFaq === idx ? 'bg-[#5A6ED8]/10 border-[#5A6ED8]/30' : ''}`}>
              <button 
                onClick={() => setActiveFaq(activeFaq === idx ? null : idx)}
                className="w-full px-5 py-4 flex items-center justify-between text-left"
              >
                <span className={`text-xs font-[800] uppercase tracking-tight ${activeFaq === idx ? 'text-[#5A6ED8]' : 'text-zinc-300'}`}>{faq.question}</span>
                {activeFaq === idx ? <ChevronUp size={16} className="text-[#5A6ED8]" /> : <ChevronDown size={16} className="text-zinc-500" />}
              </button>
              {activeFaq === idx && (
                <div className="px-5 pb-4 pt-0">
                  <p className="text-[#CFD0D8] text-xs leading-relaxed font-medium">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Footer Credentials */}
      <footer className="w-full max-w-md px-6 py-12 text-center border-t border-white/5 mt-auto">
        <p className="text-white/20 text-[9px] font-black uppercase tracking-[0.3em] mb-4">Guia Nova CNH © 2026</p>
        <div className="flex justify-center gap-4">
             <span className="text-white/20 text-[9px] font-bold cursor-pointer hover:text-white transition-colors">Termos</span>
             <span className="text-white/20 text-[9px] font-bold cursor-pointer hover:text-white transition-colors">Privacidade</span>
             <span className="text-white/20 text-[9px] font-bold cursor-pointer hover:text-white transition-colors">Contato</span>
        </div>
      </footer>

      {/* Notificação Sticky */}
      <div className={`fixed top-20 right-4 z-[200] transition-all duration-500 ${showNotification ? 'translate-x-0 opacity-100' : 'translate-x-10 opacity-0 pointer-events-none'}`}>
        <div className="glass-card bg-[#000018]/90 p-3 rounded-xl flex items-center gap-3 shadow-2xl border-emerald-500/30 backdrop-blur-xl max-w-[280px]">
          <div className="bg-emerald-500 rounded-full p-1.5 flex-shrink-0">
            <CheckCircle size={14} className="text-[#000018]" />
          </div>
          <div>
            <p className="text-[9px] text-emerald-400 font-black uppercase leading-none mb-1">Compra Verificada</p>
            <p className="text-[10px] text-white font-bold leading-tight">Gabriel do RJ acabou de entrar na turma.</p>
          </div>
        </div>
      </div>

      {/* Fixed CTA Mobile */}
      <div className="fixed bottom-0 left-0 right-0 p-4 pb-6 bg-gradient-to-t from-[#000018] via-[#000018] to-transparent z-[999]">
        <div className="max-w-md mx-auto">
             <button 
              onClick={handleCheckout}
              disabled={isRedirecting}
              className={`w-full py-4 text-[#000018] font-[1000] rounded-2xl shadow-[0_0_30px_rgba(16,185,129,0.3)] flex items-center justify-center gap-2 text-sm uppercase tracking-wide transform active:scale-95 transition-transform ${planType === 'ebook' ? 'bg-emerald-500' : 'bg-white'}`}
            >
              {isRedirecting ? <div className="w-4 h-4 border-2 border-[#000018] border-t-transparent rounded-full animate-spin"></div> : <Key size={18} fill="currentColor" />}
              {isRedirecting ? 'PROCESSANDO...' : (planType === 'ebook' ? 'Desbloquear Guia (R$ 29,90)' : 'Entrar no Clube (R$ 19,90)')}
            </button>
        </div>
      </div>

    </div>
  );
};

export default App;
